package com.example.aquasensewater;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;

import androidx.cardview.widget.CardView;
import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class HomeFragment extends Fragment implements View.OnClickListener {

    //Clickable function of each card
    public CardView ph, tds, turbidity, temp;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        //return inflater.inflate(R.layout.fragment_home, container, false);
        View view = inflater.inflate(R.layout.fragment_home, container, false);
        // Initialize views here, after the layout has been inflated

        ph = view.findViewById(R.id.ph);
        tds = view.findViewById(R.id.tds);
        turbidity = view.findViewById(R.id.turbidity);
        temp = view.findViewById(R.id.temp);

        ph.setOnClickListener(this);
        tds.setOnClickListener(this);
        turbidity.setOnClickListener(this);
        temp.setOnClickListener(this);
        return view;
    }

    @Override
    public void onClick(View v) {
        Intent i;

        switch (v.getId()) {
            case R.id.ph:
                i = new Intent(getActivity(), phlevel.class);
                startActivity(i);
                break;

            case R.id.tds:
                i = new Intent(getActivity(), tds.class);
                startActivity(i);
                break;

            case R.id.turbidity:
                i = new Intent(getActivity(), turbidity.class);
                startActivity(i);
                break;

            case R.id.temp:
                i = new Intent(getActivity(), temperature.class);
                startActivity(i);
                break;
        }
    }
}