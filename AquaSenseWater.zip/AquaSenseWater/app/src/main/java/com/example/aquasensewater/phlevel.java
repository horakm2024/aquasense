package com.example.aquasensewater;

import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import com.google.android.material.bottomnavigation.BottomNavigationView;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class phlevel extends AppCompatActivity {

    TextView valueTextph;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_phlevel);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        FirebaseDatabase database = FirebaseDatabase.getInstance("https://aquasense-12265-default-rtdb.asia-southeast1.firebasedatabase.app/");
        DatabaseReference myRef = database.getReference("pHlevelsensorid");

        valueTextph =findViewById(R.id.valueTextph);

        myRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                // This method is called once with the initial value and again
                // whenever data at this location is updated.

                Object value = dataSnapshot.getValue(); // Get the value as an Object

                if (value instanceof Long) {
                    // If the value is a Long, handle it accordingly
                    valueTextph.setText(String.valueOf((Long) value));
                } else if (value instanceof Double) {
                    // If the value is a Double (for decimal numbers), handle it
                    valueTextph.setText(String.valueOf((Double) value));
                } else if (value instanceof String) {
                    // If the value is already a String, set it directly
                    valueTextph.setText((String) value);
                } else {
                    // Handle other cases or show an error message
                    valueTextph.setText("Error: Unsupported data type");
                }
            }

            @Override
            public void onCancelled(DatabaseError error) {
                // Failed to read value
            }
        });

        BottomNavigationView bottomNavigationView = findViewById(R.id.bottomNavigationView);
        bottomNavigationView.setSelectedItemId(R.id.bottomNavigationView);

        bottomNavigationView.setOnItemSelectedListener(item -> {
            switch (item.getItemId()){
                case R.id.backhome:
                    startActivity(new Intent(getApplicationContext(), MainActivity.class));
                    return true;
            }
            return false;
        });
    }
}
