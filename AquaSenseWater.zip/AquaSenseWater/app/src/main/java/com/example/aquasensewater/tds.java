package com.example.aquasensewater;

import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.google.android.material.bottomnavigation.BottomNavigationView;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class tds extends AppCompatActivity {

    TextView valueTexttds;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_tds);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        FirebaseDatabase database = FirebaseDatabase.getInstance("https://aquasense-12265-default-rtdb.asia-southeast1.firebasedatabase.app/");
        DatabaseReference myRef = database.getReference("tdssensorid");

        valueTexttds =findViewById(R.id.valueTexttds);

        myRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                // This method is called once with the initial value and again
                // whenever data at this location is updated.

                Object value = dataSnapshot.getValue(); // Get the value as an Object

                if (value instanceof Long) {
                    // If the value is a Long, handle it accordingly
                    valueTexttds.setText(String.valueOf((Long) value));
                } else if (value instanceof Double) {
                    // If the value is a Double (for decimal numbers), handle it
                    valueTexttds.setText(String.valueOf((Double) value));
                } else if (value instanceof String) {
                    // If the value is already a String, set it directly
                    valueTexttds.setText((String) value);
                } else {
                    // Handle other cases or show an error message
                    valueTexttds.setText("Error: Unsupported data type");
                }
            }

            @Override
            public void onCancelled(DatabaseError error) {
                // Failed to read value
            }
        });

        BottomNavigationView bottomNavigationView = findViewById(R.id.bottomNavigationView);
        bottomNavigationView.setSelectedItemId(R.id.bottomNavigationView);

        bottomNavigationView.setOnItemSelectedListener(item -> {
            switch (item.getItemId()) {
                case R.id.backhome:
                    startActivity(new Intent(getApplicationContext(), MainActivity.class));
                    return true;
            }
            return false;
        });
    }
}
